Pour executer ouvrir le fichier chansonOntologie.owl avec protege, il manque une relation que nous mettrons en place la prochaine fois (le role d'un membre d'un groupe).
